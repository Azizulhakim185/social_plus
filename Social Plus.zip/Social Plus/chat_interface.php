<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Chat with User ID: <?php echo htmlspecialchars($_GET['user_id']); ?></h2>
        <div id="chat-container" class="border p-3" style="height: 300px; overflow-y: scroll;"></div>
        <textarea id="message" class="form-control mt-3" rows="3" placeholder="Type your message..."></textarea>
        <button id="send-btn" class="btn btn-primary mt-2">Send</button>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        const toUserId = <?php echo json_encode($_GET['user_id']); ?>;

        function fetchChat() {
            $.ajax({
                url: 'chat.php',
                type: 'POST',
                data: { fetchChat: true, to_user_id: toUserId },
                dataType: 'json',
                success: function (response) {
                    $('#chat-container').empty();
                    response.messages.forEach(msg => {
                        $('#chat-container').append(`
                        <div class="${msg.from_user_id == toUserId ? 'text-left' : 'text-right'}">
                            <strong>${msg.from_user_id}:</strong> ${msg.msg}
                        </div>
                    `);
                    });
                    $('#chat-container').scrollTop($('#chat-container')[0].scrollHeight); // Scroll to the bottom
                }
            });
        }

        $(document).ready(function () {
            const toUserId = <?php echo json_encode($_GET['user_id']); ?>;

            function fetchChat() {
                $.ajax({
                    url: 'assets/php/chat.php',
                    type: 'POST',
                    data: { fetchChat: true, to_user_id: toUserId },
                    dataType: 'json',
                    success: function (response) {
                        $('#chat-container').empty();
                        if (response.messages) {
                            response.messages.forEach(msg => {
                                $('#chat-container').append(`
                            <div class="${msg.from_user_id == toUserId ? 'text-left' : 'text-right'}">
                                <strong>${msg.from_user_id}:</strong> ${msg.msg}
                            </div>
                        `);
                            });
                        } else {
                            console.error("Error fetching messages:", response.message);
                        }
                        $('#chat-container').scrollTop($('#chat-container')[0].scrollHeight); // Scroll to the bottom
                    },
                    error: function (xhr, status, error) {
                        console.error("AJAX Error:", status, error);
                        console.log(xhr.responseText); // Log the response to see the error
                    }
                });
            }

            $('#send-btn').click(function () {
                const message = $('#message').val();
                if (message) {
                    $.ajax({
                        url: 'chat.php',
                        type: 'POST',
                        data: { sendMessage: true, to_user_id: toUserId, msg: message },
                        dataType: 'json',
                        success: function (response) {
                            if (response.status === 'success') {
                                $('#message').val(''); // Clear the message input
                                fetchChat(); // Refresh chat
                            } else {
                                console.error("Error sending message:", response.message);
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX Error:", status, error);
                            console.log(xhr.responseText); // Log the response to see the error
                        }
                    });
                }
            });

            fetchChat(); // Initial fetch
            setInterval(fetchChat, 5000); // Fetch messages every 5 seconds
        });

    </script>
</body>

</html>