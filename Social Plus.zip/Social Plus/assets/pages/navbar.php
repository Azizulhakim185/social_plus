<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Plus Navbar</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-white border">
        <div class="container col-9 d-flex justify-content-between">
            <div class="d-flex justify-content-between col-8">
                <a class="navbar-brand" href="#">
                    <img src="assets/image/Social_Plus2.png" alt="Social Plus" width="200" height="60">
                </a>

                <form class="d-flex" action="assets/pages/search.php" method="GET">
                    <input class="form-control me-2" type="search" name="query" placeholder="Looking for someone.."
                        aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link text-dark" href="index.php"><i class="bi bi-house-door-fill"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" data-bs-toggle="modal" data-bs-target="#addpost" href="#"><i
                            class="bi bi-plus-square-fill"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" id="notification-icon" data-bs-toggle="offcanvas"
                        data-bs-target="#notificationSidebar" aria-controls="notificationSidebar">
                        <i class="fas fa-bell"></i>
                        <span id="notification-count" class="badge bg-danger">0</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="#"><i class="bi bi-chat-right-dots-fill"></i></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="assets/image/profile/<?php echo $user['profile_pic']; ?>" alt="Profile" height="30"
                            width="30" class="rounded-circle border">
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="?editprofile">Edit Profile</a></li>
                        <li><a class="dropdown-item" href="#">Account Settings</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="?logout">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>


    <div class="offcanvas offcanvas-end notification-sidebar" tabindex="-1" id="notificationSidebar"
        aria-labelledby="notificationSidebarLabel">
        <div class="offcanvas-header">
            <h5 id="notificationSidebarLabel" class="fw-bold">Notifications</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body p-0">
            <ul id="notification-list" class="list-group list-group-flush">

                <li class="list-group-item no-notification-item">
                    <div class="no-notification-message">No new notifications</div>
                </li>
            </ul>
        </div>
    </div>


    <style>
        .notification-sidebar {
            background-color: #f8f9fa;

        }

        .notification-sidebar .offcanvas-header {
            background-color: #343a40;

            color: #fff;

            border-bottom: 1px solid #dee2e6;

        }

        .notification-sidebar .offcanvas-body {
            padding: 0;

        }

        .notification-sidebar .list-group-item {
            border: none;

            border-bottom: 1px solid #dee2e6;

            font-size: 0.9rem;

            padding: 15px 20px;

            background-color: #fff;

            transition: background-color 0.3s ease;

        }

        .notification-sidebar .list-group-item:hover {
            background-color: #e9ecef;

        }

        .notification-sidebar .list-group-item:last-child {
            border-bottom: none;

        }

        .notification-sidebar h5 {
            font-size: 1.25rem;

            margin-bottom: 0;

        }

        .notification-sidebar .btn-close {
            filter: brightness(0) invert(1);

        }


        .no-notification-item {
            text-align: center;
            background-color: #f1f1f1;

        }

        .no-notification-message {
            font-weight: bold;

            color: #6c757d;

            padding: 20px;

        }
    </style>


    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

</body>

</html>