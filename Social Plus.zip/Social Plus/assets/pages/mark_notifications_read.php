<?php
session_start();
include_once 'assets/php/Function.php';

$userId = $_SESSION['userdata']['id']; // Ensure user ID is from session

$conn = new mysqli('localhost', 'username', 'password', 'database');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$stmt->close();
?>