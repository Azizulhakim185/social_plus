<?php

include('../php/Function.php');


if (isset($_GET['query'])) {
    $searchQuery = trim($_GET['query']);

   
    if (empty($searchQuery)) {
        echo "No search query provided.";
        exit;
    }

    
    $stmt = $conn->prepare("SELECT id, first_name, last_name, profile_pic FROM users WHERE first_name LIKE ? OR last_name LIKE ?");
    $searchParam = "%" . $searchQuery . "%";
    $stmt->bind_param('ss', $searchParam, $searchParam);
    $stmt->execute();
    $result = $stmt->get_result();

   
    if ($user = $result->fetch_assoc()) {
        $userId = $user['id'];
        $firstName = htmlspecialchars($user['first_name']);
        $lastName = htmlspecialchars($user['last_name']);
        $profilePic = htmlspecialchars($user['profile_pic']);


        $isFollowing = false; 

       
        echo "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta http-equiv='X-UA-Compatible' content='IE=edge'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <link href='../bootstrap/css/bootstrap.min.css' rel='stylesheet'>
            <link href='../bootstrap/icons/bootstrap-icons.css' rel='stylesheet'>
            <link href='../css/custom.css' rel='stylesheet'>
            <title>$firstName $lastName</title>
        </head>
        <body>
        <nav class='navbar navbar-expand-lg navbar-light bg-white border'>
            <!-- Navbar content here -->
        </nav>
        <div class='container col-9 rounded-0'>
            <div class='col-12 rounded p-4 mt-4 d-flex gap-5'>
                <div class='col-4 d-flex justify-content-end align-items-start'>
                    <img src='../image/profile/$profilePic' class='img-thumbnail rounded-circle my-3' style='height:170px;' alt='Profile Picture'>
                </div>
                <div class='col-8'>
                    <div class='d-flex flex-column'>
                        <div class='d-flex gap-5 align-items-center'>
                            <span style='font-size: xx-large;'>$firstName $lastName</span>
                            <div class='dropdown'>
                                <span class='' style='font-size:xx-large' type='button' id='dropdownMenuButton1' data-bs-toggle='dropdown' aria-expanded='false'>
                                    <i class='bi bi-three-dots'></i>
                                </span>
                                <ul class='dropdown-menu' aria-labelledby='dropdownMenuButton1'>
                                    <li><a class='dropdown-item' href='#'><i class='bi bi-chat-fill'></i> Message</a></li>
                                    <li><a class='dropdown-item' href='#'><i class='bi bi-x-circle-fill'></i> Block</a></li>
                                </ul>
                            </div>
                        </div>
                        <span style='font-size: larger;' class='text-secondary'>@$firstName</span>
                    
                        <form action='../php/follow.php' method='post'>
                            <input type='hidden' name='user_id' value='$userId'>
                            <button type='submit' class='btn btn-primary'>" . ($isFollowing ? "Unfollow" : "Follow") . "</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class='col-12 mt-4'>
                <h3>Posts</h3>
                <div class='row'>";

       
        $stmtPosts = $conn->prepare("SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC");
        $stmtPosts->bind_param('i', $userId);
        $stmtPosts->execute();
        $posts = $stmtPosts->get_result();

        if ($posts->num_rows > 0) {
            while ($post = $posts->fetch_assoc()) {
                $postImage = htmlspecialchars($post['post_img']);
                $postText = htmlspecialchars($post['post_text']); 
                echo "
                <div class='col-md-4 mb-3'>
                    <div class='card'>
                        <img src='../image/post/$postImage' class='card-img-top' alt='Post Image'>
                        <div class='card-body'>
                            <p class='card-text'>$postText</p>
                        </div>
                    </div>
                </div>";
            }
        } else {
            echo "<p>No posts found.</p>";
        }

        echo "
                </div>
            </div>
        </div>
        <script src='../bootstrap/js/bootstrap.bundle.min.js'></script>
        <script src='../js/jquery-3.7.1.min.js'></script>
        <script src='../js/custom.js'></script>
        </body>
        </html>";

        $stmtPosts->close();
    } else {
        echo "No user found.";
    }

    $stmt->close();
} else {
    echo "No search query provided.";
}

$conn->close();
?>