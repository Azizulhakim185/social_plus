document.addEventListener('DOMContentLoaded', function () {
    // Preview image upload
    var input = document.querySelector("#select_post_img");
    input.addEventListener("change", preview);

    function preview() {
        var fileobject = this.files[0];
        var filereader = new FileReader();
        filereader.readAsDataURL(fileobject);
        filereader.onload = function () {
            var image_src = filereader.result;
            var image = document.querySelector("#post_img");
            image.setAttribute('src', image_src);
            image.setAttribute('style', 'display:block');
        }
    }

    // Follow the user
    $(".followbtn").click(function () {
        var user_id_v = $(this).data('userId');
        var button = this;
        $(button).attr('disabled', true);
        $.ajax({
            url: 'assets/php/ajax.php?follow',
            method: 'post',
            dataType: 'json',
            data: { user_id: user_id_v },
            success: function (response) {
                if (response.status) {
                    $(button).data('userId', 0);
                    $(button).html('<i class="bi bi-check-circle-fill"></i> Followed');
                } else {
                    $(button).attr('disabled', false);
                    alert('Something went wrong, please try again later.');
                }
            }
        });
    });


    // Unfollow the user
    $(".unfollowbtn").click(function () {
        var user_id_v = $(this).data('userId');
        var button = this;
        $(button).attr('disabled', true);
        $.ajax({
            url: 'assets/php/ajax.php?unfollow',
            method: 'post',
            dataType: 'json',
            data: { user_id: user_id_v },
            success: function (response) {
                if (response.status) {
                    $(button).data('userId', 0);
                    $(button).html('<i class="bi bi-check-circle-fill"></i> Unfollowed');
                } else {
                    $(button).attr('disabled', false);
                    alert('Something went wrong, please try again later.');
                }
            }
        });
    });


   // Like the post
$(".like_btn").click(function () {
    var post_id_v = $(this).data('postId');
    var button = this;
    $(button).attr('disabled', true);

    $.ajax({
        url: 'assets/php/ajax.php?like',
        method: 'post',
        dataType: 'json',
        data: { post_id: post_id_v },
        success: function (response) {
            if (response.status) {
                $(button).hide();
                $(button).siblings('.unlike_btn').show();

                // Update the like count without affecting the comment count
                var likeCountElement = $(button).closest('.card').find('.like-count');
                var likeCount = parseInt(likeCountElement.text().split(" ")[0]);
                likeCountElement.text((likeCount + 1) + " likes");

                $(button).attr('disabled', false);
            } else {
                $(button).attr('disabled', false);
                alert('Something went wrong, please try again later.');
            }
        }
    });
});

// Unlike the post
$(".unlike_btn").click(function () {
    var post_id_v = $(this).data('postId');
    var button = this;
    $(button).attr('disabled', true);

    $.ajax({
        url: 'assets/php/ajax.php?unlike',
        method: 'post',
        dataType: 'json',
        data: { post_id: post_id_v },
        success: function (response) {
            if (response.status) {
                $(button).hide();
                $(button).siblings('.like_btn').show();

                // Update the like count without affecting the comment count
                var likeCountElement = $(button).closest('.card').find('.like-count');
                var likeCount = parseInt(likeCountElement.text().split(" ")[0]);
                likeCountElement.text((likeCount - 1) + " likes");

                $(button).attr('disabled', false);
            } else {
                $(button).attr('disabled', false);
                alert('Something went wrong, please try again later.');
            }
        }
    });
});


    // Adding Comment
    $(".add-comment").click(function () {
        var button = this;
        var comment_v = $(button).siblings('.comment-input').val();
        if (comment_v === '') {
            return 0;
        }
        var post_id_v = $(this).data('postId');
        var commentSectionId = "comment-section" + post_id_v;
        var page = $(this).data('page');

        $(button).attr('disabled', true);
        $(button).siblings('.comment-input').attr('disabled', true);

        $.ajax({
            url: 'assets/php/ajax.php?addcomment',
            method: 'post',
            dataType: 'json',
            data: { post_id: post_id_v, comment: comment_v },
            success: function (response) {
                if (response.status) {
                    $(button).attr('disabled', false);
                    $(button).siblings('.comment-input').attr('disabled', false);
                    $(button).siblings('.comment-input').val('');

                    // Remove "no comments" message if it exists
                    $("#" + commentSectionId).find('.no-comments').remove();

                    $("#" + commentSectionId).append(response.comment);
                    
                    // Update the comment count on the post
                    var commentCountElement = $(button).closest('.post').find('.comment-count');
                    commentCountElement.text(response.comment_count);
                    location.reload();
                    if(page === 'wall'){
                        location.reload();
                    }
                } else {
                    $(button).attr('disabled', false);
                    $(button).siblings('.comment-input').attr('disabled', false);
                    alert('Something went wrong, please try again later.');
                }
            }
        });
    });


// Function to fetch and update notifications
function fetchNotifications() {
    fetch('assets/php/fetch_notifications.php') // Ensure the correct file path
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();  // This will parse the JSON response
        })
        .then(data => {
            console.log('Fetched Data:', data);  // Log the data to ensure it's correct
            const notificationList = document.getElementById('notification-list');
            const notificationCount = document.getElementById('notification-count');

            // Clear existing notifications
            notificationList.innerHTML = '';

            // Update the notification count
            notificationCount.textContent = data.count > 0 ? data.count : 0;

            // If there are no notifications, show a message
            if (data.count === 0) {
                notificationList.innerHTML = '<li>No new notifications</li>';
            } else {
                // Loop through the notifications and display them
                data.notifications.forEach(notification => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${notification.message} - ${new Date(notification.created_at).toLocaleTimeString()}`;
                    notificationList.appendChild(listItem);
                });
            }
        })
        .catch(error => console.error('Error fetching notifications:', error));
}

// Fetch notifications when the page loads
document.addEventListener('DOMContentLoaded', fetchNotifications);

// Fetch notifications every 60 seconds to keep them updated
setInterval(fetchNotifications, 60000);


});
