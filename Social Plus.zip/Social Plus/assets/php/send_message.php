<?php

include 'assets/php/Function.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $from_user_id = $_SESSION['user_id']; 
    $to_user_id = $_POST['to_user_id'];
    $msg = $_POST['msg'];

    if (sendMessage($from_user_id, $to_user_id, $msg)) {
        echo "Message sent!";
    } else {
        echo "Error sending message.";
    }
}
?>