<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start(); 


$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "social_plus"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$userId = $_SESSION['userdata']['id']; 


$sql = "SELECT message, created_at FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = [
        'message' => $row['message'],
        'created_at' => $row['created_at']
    ];
}

$response = [
    'count' => count($notifications),
    'notifications' => $notifications
];


header('Content-Type: application/json');
echo json_encode($response);


$stmt->close();
$conn->close();
?>