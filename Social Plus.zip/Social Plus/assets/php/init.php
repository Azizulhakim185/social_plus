<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$conn = new mysqli('localhost', 'your_username', 'your_password', 'chat_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>