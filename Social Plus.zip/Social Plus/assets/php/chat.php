<?php
session_start();
include 'assets/php/init.php'; 
include 'assets/php/Function.php'; 


error_reporting(E_ALL);
ini_set('display_errors', 1);


if (!isset($_SESSION['userdata'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    if (isset($_POST['sendMessage'])) {
        $from_user_id = $_SESSION['userdata']['id'];
        $to_user_id = $_POST['to_user_id'];
        $msg = $_POST['msg'];

        if (sendMessage($from_user_id, $to_user_id, $msg)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to send message']);
        }
        exit;
    }
   
    if (isset($_POST['fetchChat'])) {
        $user_id1 = $_SESSION['userdata']['id'];
        $user_id2 = $_POST['to_user_id'];

        $messages = getChat($user_id1, $user_id2);
        echo json_encode(['messages' => $messages]);
        exit;
    }

    if (isset($_POST['markRead'])) {
        $from_user_id = $_POST['from_user_id'];
        $to_user_id = $_POST['to_user_id'];

        markMessagesAsRead($from_user_id, $to_user_id);
        echo json_encode(['status' => 'success']);
        exit;
    }
}

echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
?>