<?php
require_once 'Function.php';

if (isset($_GET['follow'])) {
    $user_id = $_POST['user_id'];
    $response = ['status' => followUser(user_id: $user_id)];
    echo json_encode(value: $response);
}

if (isset($_GET['unfollow'])) {
    $user_id = $_POST['user_id'];
    $response = ['status' => unfollowUser(user_id: $user_id)];
    echo json_encode(value: $response);
}

if (isset($_GET['like'])) {
    $post_id = $_POST['post_id'];
    $response = [];

    if (!checkLikeStatus(post_id: $post_id)) {
        if (like(post_id: $post_id)) {
            $response['status'] = true;
        } else {
            $response['status'] = false;
        }
    }

    echo json_encode(value: $response);
}

if (isset($_GET['unlike'])) {
    $post_id = $_POST['post_id'];
    $response = [];

    if (checkLikeStatus(post_id: $post_id)) {
        if (unlike(post_id: $post_id)) {
            $response['status'] = true;
        } else {
            $response['status'] = false;
        }
    }

    echo json_encode(value: $response);
}

if (isset($_GET['addcomment'])) {
    $post_id = $_POST['post_id'];
    $comment = $_POST['comment'];
    $response = [];

    if (addComment(post_id: $post_id, comment: $comment)) {
        $comment_user = getUser(user_id: $_SESSION['userdata']['id']);
        $response['status'] = true;
        $response['comment_count'] = getCommentCount(post_id: $post_id); // Return the updated comment count
        $response['comment'] = '<div class="d-flex align-items-center p-2">
                            <div><img src="assets/image/profile/' . $comment_user['profile_pic'] . '" alt="" height="40" class="rounded-circle border"></div>
                            <div>&nbsp;&nbsp;&nbsp;</div>
                            <div class="d-flex flex-column justify-content-start align-items-start">
                                <h6 style="margin: 0px;">@' . $comment_user['user_name'] . '</h6>
                                <p style="margin:0px;" class="text-muted">' . htmlspecialchars($comment) . '</p>
                            </div>
                        </div>';
    } else {
        $response['status'] = false;
    }

    echo json_encode(value: $response);
    exit;
}
