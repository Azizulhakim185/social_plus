<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';


$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


function showPage($page, $data = "")
{
    include("assets/pages/$page.php");
}

function followUser($user_id)
{
    global $conn;
    $current_user = $_SESSION['userdata']['id'];

   
    $query = "INSERT INTO follow_list(follower_id, user_id) VALUES ($current_user, $user_id)";
    $result = mysqli_query($conn, $query);

   
    if ($result) {
        $current_user_name = $_SESSION['userdata']['user_name'];
        addNotification($user_id, 'follow', $current_user, 'User @' . $current_user_name . ' followed you.');
    }

    return $result;
}



function checkLikeStatus($post_id)
{
    global $conn;
    $current_user = $_SESSION['userdata']['id'];
    $query = "SELECT count(*) as row FROM likes WHERE user_id = $current_user AND post_id = $post_id";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($run)['row'];
}

function like($post_id)
{
    global $conn;
    $current_user = $_SESSION['userdata']['id'];
    $current_user_name = $_SESSION['userdata']['user_name'];

   
    $query = "INSERT INTO likes(post_id, user_id) VALUES ($post_id, $current_user)";
    $result = mysqli_query($conn, $query);

   
    if ($result) {
        $post_owner_id = getPostOwner($post_id);
        addNotification($post_owner_id, 'like', $post_id, 'User @' . $current_user_name . ' liked your post.');
    }

    return $result;
}


function addComment($post_id, $comment)
{
    global $conn;
    $comment = mysqli_real_escape_string($conn, $comment);
    $current_user = $_SESSION['userdata']['id'];
    $current_user_name = $_SESSION['userdata']['user_name'];

   
    $query = "INSERT INTO comments(user_id, post_id, comment) VALUES ($current_user, $post_id, '$comment')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $post_owner_id = getPostOwner($post_id);
        addNotification($post_owner_id, 'comment', $post_id, 'User @' . $current_user_name . ' commented on your post.');
    }

    return $result;
}



function getCommentCount($post_id): mixed
{
    global $conn;
    $query = "SELECT COUNT(*) as comment_count FROM comments WHERE post_id = $post_id";
    $run = mysqli_query(mysql: $conn, query: $query);
    $result = mysqli_fetch_assoc(result: $run);
    return $result['comment_count'];
}


function getComments($post_id): array
{
    global $conn;
    $query = "SELECT * FROM comments WHERE post_id = $post_id";
    $run = mysqli_query(mysql: $conn, query: $query);
    return mysqli_fetch_all(result: $run, mode: MYSQLI_ASSOC); // Return array of comments
}


function unlike($post_id): bool|mysqli_result
{
    global $conn;
    $current_user = $_SESSION['userdata']['id'];
    $query = "DELETE FROM likes WHERE user_id = $current_user AND post_id = $post_id";
    return mysqli_query(mysql: $conn, query: $query);
}


function getlikes($post_id): array
{
    global $conn;
    $query = "SELECT * FROM likes WHERE post_id = $post_id";
    $run = mysqli_query(mysql: $conn, query: $query);
    return mysqli_fetch_all(result: $run, mode: MYSQLI_ASSOC);
}


function unfollowUser($user_id): bool|mysqli_result
{
    global $conn;

    $current_user = $_SESSION['userdata']['id'];
    $query = "DELETE FROM follow_list WHERE follower_id= $current_user && user_id=$user_id";
    return mysqli_query(mysql: $conn, query: $query);

}


function addNotification($user_id, $type, $reference_id, $message)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, type, reference_id, message, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param('isis', $user_id, $type, $reference_id, $message);
    $stmt->execute();
    $stmt->close();
}

function getPostOwner($post_id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $post = $result->fetch_assoc();
    $stmt->close();

    return $post['user_id']; 
}


function showError($field): void
{
    if (isset($_SESSION['error'])) {
        $error = $_SESSION['error'];
        if (isset($error['field']) && $field == $error['field']) {
            ?>
            <div class="alert alert-danger my-2" role="alert">
                <?php echo $error['msg']; ?>
            </div>
            <?php
        }
    }
}


function showFormData($field): mixed
{
    if (isset($_SESSION['formdata'])) {
        $form_data = $_SESSION['formdata'];
        return isset($form_data[$field]) ? $form_data[$field] : null;
    }
    return null;
}


function isEmailRegistered($email)
{
    global $conn;

    $query = "SELECT count(*) FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        return $row[0] > 0;
    } else {
        return false;
    }
}


function isUsernameRegistered($user_name)
{
    global $conn;

    $query = "SELECT count(*) FROM users WHERE user_name='$user_name'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        return $row[0] > 0;
    } else {
        return false;
    }
}

function isUsernameRegisteredByOther($user_name)
{
    global $conn;
    $user_id = $_SESSION['userdata']['id'];
    $query = "SELECT count(*) FROM users WHERE user_name='$user_name' AND id != $user_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        return $row[0] > 0;
    } else {
        return false;
    }
}


function validateSignupForm($form_data)
{
    $response = array();
    $response['status'] = true;

    if (empty($form_data['password'])) {
        $response['msg'] = "Password is not given";
        $response['status'] = false;
        $response['field'] = 'password';
    }

    if (empty($form_data['username'])) {
        $response['msg'] = "Username is not given";
        $response['status'] = false;
        $response['field'] = 'username';
    }

    if (empty($form_data['email'])) {
        $response['msg'] = "Email is not given";
        $response['status'] = false;
        $response['field'] = 'email';
    }

    if (empty($form_data['last_name'])) {
        $response['msg'] = "Last name is not given";
        $response['status'] = false;
        $response['field'] = 'last_name';
    }

    if (empty($form_data['first_name'])) {
        $response['msg'] = "First name is not given";
        $response['status'] = false;
        $response['field'] = 'first_name';
    }

    if (isEmailRegistered($form_data['email'])) {
        $response['msg'] = "Email Id is already registered";
        $response['status'] = false;
        $response['field'] = 'email';
    }

    if (isUsernameRegistered($form_data['username'])) {
        $response['msg'] = "Username is already registered";
        $response['status'] = false;
        $response['field'] = 'username';
    }

    return $response;
}

function validateLoginForm($form_data)
{
    $response = array();
    $response['status'] = true;
    $blank = false;

    if (empty($form_data['password'])) {
        $response['msg'] = "Password is not given";
        $response['status'] = false;
        $response['field'] = 'password';
        $blank = true;
    }

    if (empty($form_data['username_email'])) {
        $response['msg'] = "Username/email is not given";
        $response['status'] = false;
        $response['field'] = 'username_email';
        $blank = true;
    }

    $user = checkUser($form_data);
    if (!$blank && !$user['status']) {
        $response['msg'] = "Incorrect username/email or password";
        $response['status'] = false;
        $response['field'] = 'checkuser';
    } else {
        $response['user'] = $user['user'];
    }

    return $response;
}


function checkUser($login_data)
{
    global $conn;

    $username_email = $login_data['username_email'];
    $password = md5($login_data['password']);

    $query = "SELECT * FROM users WHERE (email='$username_email' OR user_name='$username_email') AND password='$password'";
    $run = mysqli_query($conn, $query);
    $data['user'] = mysqli_fetch_assoc($run) ?? array();

    if (count($data['user']) > 0) {
        $data['status'] = true;
    } else {
        $data['status'] = false;
    }

    return $data;
}

function createUser($data)
{
    global $conn;

    $first_name = mysqli_real_escape_string($conn, $data['first_name']);
    $last_name = mysqli_real_escape_string($conn, $data['last_name']);
    $gender = $data['gender'];
    $email = mysqli_real_escape_string($conn, $data['email']);
    $user_name = mysqli_real_escape_string($conn, $data['username']);
    $password = mysqli_real_escape_string($conn, $data['password']);
    $password = md5($password);

    $query = "INSERT INTO users (first_name, last_name, gender, email, user_name, password) VALUES ('$first_name', '$last_name', '$gender', '$email', '$user_name', '$password')";

    return mysqli_query($conn, $query);
}


function getUser($user_id)
{
    global $conn;

    $query = "SELECT * FROM users WHERE id=$user_id";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($run);
}

function filterFollowSuggestion()
{
    $list = getFollowSuggestions();
    $filter_list = array();
    foreach ($list as $user) {
        if (!checkFollowStatus($user['id']) && count($filter_list) < 5) {
            $filter_list[] = $user;
        }
    }
    return $filter_list;
}


function checkFollowStatus($user_id)
{
    global $conn;
    $current_user = $_SESSION['userdata']['id'];
    $query = "SELECT count(*) as row FROM follow_list WHERE follower_id = $current_user 
    && user_id=$user_id";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($run)['row'];

}


function getFollowSuggestions()
{
    global $conn;

    $current_user = $_SESSION['userdata']['id'];
    $query = "SELECT * FROM users WHERE id!=$current_user";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_all($run, true);

}


function getFollowers($user_id)
{
    global $conn;
    $query = "SELECT * FROM follow_list WHERE user_id=$user_id";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_all($run, true);
}


function getFollowing($user_id)
{
    global $conn;
    $query = "SELECT * FROM follow_list WHERE follower_id=$user_id";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_all($run, true);
}


function getPostById($user_id)
{
    global $conn;

    $query = "SELECT * FROM posts WHERE user_id=$user_id ORDER BY id DESC";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_all($run, true);
}




function getUserByUsername($username)
{
    global $conn;

    $query = "SELECT * FROM users WHERE user_name= '$username'";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($run);
}


function validateUpdateForm($form_data, $image_data)
{
    $response = array();
    $response['status'] = true;

    if (empty($form_data['user_name'])) {
        $response['msg'] = "Username is not given";
        $response['status'] = false;
        $response['field'] = 'Username';
    }


    if (isset($image_data['name'])) {
        $image = basename($image_data['name']);
        $type = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $size = $image_data['size'] / 1000;

        
        if (!in_array($type, ['jpg', 'jpeg', 'png'])) {
            $response['msg'] = "Only jpg, jpeg, png images are allowed";
            $response['status'] = false;
            $response['field'] = 'profile_pic';
        }
        if ($size > 1000) {
            $response['msg'] = "Upload image less than 1MB";
            $response['status'] = false;
            $response['field'] = 'profile_pic';
        }
    }

    return $response;
}



function updateUser($user_id, $data, $image_data)
{
    global $conn;

    $first_name = mysqli_real_escape_string($conn, $data['first_name']);
    $last_name = mysqli_real_escape_string($conn, $data['last_name']);
    $user_name = mysqli_real_escape_string($conn, $data['username']);
    $password = isset($data['password']) ? md5($data['password']) : null;
    $profile_pic = '';

}
function updateProfile($data, $image_data)
{
    global $conn;

    if (!isset($_SESSION['userdata']['id'])) {
        echo "User ID not found in session.";
        return false;
    }

    $user_id = $_SESSION['userdata']['id'];
    $first_name = mysqli_real_escape_string($conn, $data['first_name']);
    $last_name = mysqli_real_escape_string($conn, $data['last_name']);
    $user_name = mysqli_real_escape_string($conn, $data['user_name']);
    $password = isset($data['password']) && !empty($data['password']) ? md5(mysqli_real_escape_string($conn, $data['password'])) : $_SESSION['userdata']['password'];

    $profile_pic = $_SESSION['userdata']['profile_pic'];
    $update_profile_pic = false;

    if (isset($image_data['name']) && !empty($image_data['name'])) {
        $target_dir = "assets/image/profile/";
        $profile_pic = basename($image_data['name']);
        $target_file = $target_dir . $profile_pic;

        if (!file_exists($target_dir)) {
            if (!mkdir($target_dir, 0755, true)) {
                echo "Failed to create directory: $target_dir";
                return false;
            }
        }

       
        if (is_writable($target_dir)) {
            echo "$target_dir is writable.";
        } else {
            echo "$target_dir is not writable.";
        }

        if (move_uploaded_file($image_data['tmp_name'], $target_file)) {
            echo "Profile picture uploaded successfully to " . $target_file;
            $update_profile_pic = true;
        } else {
            echo "Failed to upload profile picture. Source: " . $image_data['tmp_name'] . " Target: " . $target_file;
            return false;
        }
    }

    $query = "UPDATE users SET 
              first_name='$first_name', 
              last_name='$last_name', 
              user_name='$user_name', 
              password='$password'";

    if ($update_profile_pic) {
        $query .= ", profile_pic='$profile_pic'";
    }

    $query .= " WHERE id='$user_id'";

    if ($result = mysqli_query($conn, $query)) {
        $_SESSION['userdata']['password'] = $password; // Update session password
        if ($update_profile_pic) {
            $_SESSION['userdata']['profile_pic'] = $profile_pic; // Update session profile picture
        }
        echo "Profile updated successfully.";
        return true;
    } else {
        echo "Error executing query: " . $query . " - " . mysqli_error($conn);
        return false;
    }
}

function validatePostImage($image_data)
{
    $response = array();
    $response['status'] = true;

   
    if (!isset($image_data['name']) || empty($image_data['name'])) {
        $response['msg'] = "No image is selected";
        $response['status'] = false;
        $response['field'] = 'post_img';
    } else {
        
        $image = basename($image_data['name']);
        $type = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $size = $image_data['size'] / 1000;

      
        if (!in_array($type, ['jpg', 'jpeg', 'png'])) {
            $response['msg'] = "Only jpg, jpeg, png images are allowed";
            $response['status'] = false;
            $response['field'] = 'post_img';
        }
        if ($size > 10000) {
            $response['msg'] = "Upload image less than 1MB";
            $response['status'] = false;
            $response['field'] = 'post_img';
        }
    }

    return $response;
}


function createPost($data, $image)
{
    global $conn;

    $post_text = mysqli_real_escape_string($conn, $data['post_text']);

    $image_name = time() . basename($image['name']);
    $image_dir = "../image/post/$image_name";
    move_uploaded_file($image['tmp_name'], $image_dir);

    $user_id = $_SESSION['userdata']['id'];


    $query = "INSERT INTO posts(user_id,post_text,post_img) VALUES('$user_id','$post_text','$image_name')";

    return mysqli_query($conn, $query);
}

function getPost()
{
    global $conn;

    $query = "SELECT posts.id,posts.user_id,posts.post_img,posts.post_text,posts.created_at,
    users.first_name,users.last_name,users.user_name,users.profile_pic
     FROM posts join users on users.id=posts.user_id ORDER BY posts.created_at DESC";
    $run = mysqli_query($conn, $query);
    return mysqli_fetch_all($run, true);
}



function filterPosts()
{
    $list = getPost();
    $filter_list = array();
    foreach ($list as $post) {
        if (checkFollowStatus($post['user_id']) || $post['user_id'] == $_SESSION['userdata']['id']) {
            $filter_list[] = $post;
        }
    }
    return $filter_list;
}




function sendMessage($from_user_id, $to_user_id, $msg)
{
    global $conn;

    $stmt = $conn->prepare("INSERT INTO messages (from_user_id, to_user_id, msg) VALUES (?, ?, ?)");
    $stmt->bind_param('iis', $from_user_id, $to_user_id, $msg);
    $result = $stmt->execute();

    $stmt->close();

    return $result;
}

function getChat($user_id1, $user_id2)
{
    global $conn;

    $stmt = $conn->prepare("SELECT * FROM messages WHERE (from_user_id = ? AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = ?) ORDER BY created_at ASC");
    $stmt->bind_param('iiii', $user_id1, $user_id2, $user_id2, $user_id1);
    $stmt->execute();

    $result = $stmt->get_result();
    $messages = $result->fetch_all(MYSQLI_ASSOC);

    $stmt->close();

    return $messages;
}


function markMessagesAsRead($from_user_id, $to_user_id)
{
    global $conn;

    $stmt = $conn->prepare("UPDATE messages SET read_status = 1 WHERE from_user_id = ? AND to_user_id = ? AND read_status = 0");
    $stmt->bind_param('ii', $from_user_id, $to_user_id);
    $stmt->execute();

    $stmt->close();
}
